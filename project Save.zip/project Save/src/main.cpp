#include <Arduino.h>
#include <DFRobotDFPlayerMini.h>

HardwareSerial mySerial(1); // UART1 สำหรับ DFPlayer
DFRobotDFPlayerMini myDFPlayer;

int volumeLevel = 20; // ค่าเริ่มต้นของเสียง (0–30)

void setup() {
  Serial.begin(115200);                   // Serial Monitor
  mySerial.begin(9600, SERIAL_8N1, 2, 1); // UART1: RX=2, TX=1

  Serial.println();
  Serial.println(F("=== DFPlayer Mini Demo ==="));

  if (!myDFPlayer.begin(mySerial)) {
    Serial.println(F("DFPlayer init failed!"));
    Serial.println(F("1. ตรวจสอบสายเชื่อมต่อ DFPlayer"));
    Serial.println(F("2. ใส่ SD card ให้เรียบร้อย"));
    while (true) { delay(0); }
  }

  Serial.println(F("DFPlayer ready!"));
  myDFPlayer.volume(volumeLevel); // ตั้งระดับเสียง
}

void loop() {
  // อ่านคำสั่งจาก Serial Monitor
  if (Serial.available()) {
    char cmd = (char)Serial.read();

    switch (cmd) {
      case '1':
        myDFPlayer.play(1);
        Serial.println(F("Playing track 1"));
        break;
      case '2':
        myDFPlayer.play(2);
        Serial.println(F("Playing track 2"));
        break;
      case '3':
        myDFPlayer.play(3);
        Serial.println(F("Playing track 3"));
        break;
      case '0':
        myDFPlayer.stop();
        Serial.println(F("Stopped"));
        break;
      case '+': // เพิ่มเสียง
        if (volumeLevel < 30) {
          volumeLevel++;
          myDFPlayer.volume(volumeLevel);
          Serial.print(F("Volume: "));
          Serial.println(volumeLevel);
        } else {
          Serial.println(F("Volume already max (30)"));
        }
        break;
      case '-': // ลดเสียง
        if (volumeLevel > 0) {
          volumeLevel--;
          myDFPlayer.volume(volumeLevel);
          Serial.print(F("Volume: "));
          Serial.println(volumeLevel);
        } else {
          Serial.println(F("Volume already min (0)"));
        }
        break;
      default:
        Serial.println(F("Command not recognized (0-3, +, -)"));
        break;
    }
  }

  // ตรวจสอบสถานะเพลง (optional)
  static uint16_t lastTrack = 0;
  uint16_t currentTrack = myDFPlayer.readCurrentFileNumber();
  if (currentTrack != lastTrack && currentTrack != 0) {
    Serial.print(F("Now playing track: "));
    Serial.println(currentTrack);
    lastTrack = currentTrack;
  }
}